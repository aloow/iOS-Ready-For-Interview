/// Copyright (c) 2019 Razeware LLC
///
/// Permission is hereby granted, free of charge, to any person obtaining a copy
/// of this software and associated documentation files (the "Software"), to deal
/// in the Software without restriction, including without limitation the rights
/// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
/// copies of the Software, and to permit persons to whom the Software is
/// furnished to do so, subject to the following conditions:
///
/// The above copyright notice and this permission notice shall be included in
/// all copies or substantial portions of the Software.
///
/// Notwithstanding the foregoing, you may not use, copy, modify, merge, publish,
/// distribute, sublicense, create a derivative work, and/or sell copies of the
/// Software in any work that is designed, intended, or marketed for pedagogical or
/// instructional purposes related to programming, coding, application development,
/// or information technology.  Permission for such use, copying, modification,
/// merger, publication, distribution, sublicensing, creation of derivative works,
/// or sale is expressly withheld.
///
/// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
/// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
/// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
/// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
/// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
/// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
/// THE SOFTWARE.

@testable import DogPatch
import XCTest

class UIView_NibCreatableTests: XCTestCase {
  
  func test_nib_returnsExpected() throws {
    // given
    let nib = TestView.nib
    
    // when
    let view = try XCTUnwrap(nib.instantiate(withOwner: nil, options: nil).last)
    
    // then
    XCTAssertTrue(view is TestView)
  }
  
  func test_nibName_returnsExpected() {
    // given
    let expected = "\(TestView.self)"
    
    // when
    let actual = TestView.nibName
    
    // then
    XCTAssertEqual(actual, expected)
  }
  
  func test_nibName_canBeOverridden() {
    // given
    let expected = "SomethingElse"
    class TestView: UIView {
      override class var nibName: String { return "SomethingElse" }
    }
    
    // when
    let actual = TestView.nibName
    
    // then
    XCTAssertEqual(actual, expected)
  }
  
  func test_nibBundle_returnsExpected() {
    // given
    let expected = Bundle(for: TestView.self)
    
    // when
    let actual = TestView.nibBundle
    
    // then
    XCTAssertEqual(actual, expected)
  }
  
  func test_nibBundle_canBeOverriden() {
    // given
    class TestView: UIView {
      override class var nibBundle: Bundle? { return nil }
    }
    
    // when
    let actual = TestView.nibBundle
    
    // then
    XCTAssertNil(actual)
  }
  
  func test_instanceFromNib_returnsExpected() {
    // when
    let actual = TestView.instanceFromNib() as UIView
    
    // then
    XCTAssertTrue(actual is TestView)
  }  
}
