#  Font Awesome
Some of the icons and graphics in this app were made with the help of Font Awesome (https://fontawesome.com/license) distributed under a Creative Commons Attribution 4.0 International license

